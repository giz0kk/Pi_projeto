document.addEventListener('DOMContentLoaded', function () {
  let userPoints = 2000;

  const pointsDisplay = document.querySelector('.points-card strong');
  if (pointsDisplay) {
    pointsDisplay.textContent = userPoints;
  }

  function updatePointsDisplay() {
    const pointsDisplay = document.querySelector('.points-card strong');
    if (pointsDisplay) {
      pointsDisplay.textContent = userPoints;
    }
    localStorage.setItem('userPoints', userPoints);
  }

  const allCards = document.querySelectorAll('.card');

  allCards.forEach((card) => {
    card.addEventListener('mouseenter', () => {
      const rect = card.getBoundingClientRect();
      const spaceRight = window.innerWidth - rect.right;

      if (spaceRight < 360) {
        card.classList.add('left');
      } else {
        card.classList.remove('left');
      }
    });
  });

  const searchInput = document.querySelector('.search-box input');
  const searchButton = document.querySelector('.search-box button');
  const cards = Array.from(document.querySelectorAll('.grid-cards .card'));
  const verMaisButton = document.querySelector('.cta button');
  const feedback = document.createElement('div');
  feedback.className = 'search-feedback';
  const searchBox = document.querySelector('.search-box');

  if (searchBox) {
    searchBox.parentNode.insertBefore(feedback, searchBox.nextSibling);
  }

  function updateFeedback(message, status) {
    feedback.textContent = message;
    feedback.className = 'search-feedback ' + (status || 'info');
  }

  function filterCards() {
    const query = searchInput.value.trim().toLowerCase();
    let count = 0;

    cards.forEach((card) => {
      const text = card.innerText.toLowerCase();
      const isMatch = query === '' || text.includes(query);
      card.style.display = isMatch ? 'grid' : 'none';
      if (isMatch) count += 1;
    });

    if (!query) {
      updateFeedback('Use a pesquisa para encontrar um prêmio específico.', 'info');
    } else if (count === 0) {
      updateFeedback('Nenhum prêmio encontrado para "' + query + '".', 'error');
    } else {
      updateFeedback(count + ' prêmio(s) encontrado(s).', 'success');
    }
  }

  if (searchButton && searchInput) {
    searchButton.addEventListener('click', filterCards);
    searchInput.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        filterCards();
      }
    });
  }

  document.querySelectorAll('.resgatar-button').forEach((button) => {
    button.addEventListener('click', function () {
      if (button.disabled) return;

      const card = button.closest('.card');
      const pointsRequired = parseInt(card.dataset.points) || 0;
      const prizeName = card.querySelector('.card-title').textContent;

      if (userPoints < pointsRequired) {
        updateFeedback('Pontos insuficientes! Você precisa de ' + pointsRequired + ' pontos.', 'error');
        return;
      }

      userPoints -= pointsRequired;
      updatePointsDisplay();

      button.textContent = 'Resgatado';
      button.disabled = true;
      button.classList.add('resgatado');
      button.style.opacity = '1';
      button.style.cursor = 'default';

      // ✅ SOMENTE POPUP (sem mensagem no topo)
      showResgatePopup(prizeName, pointsRequired);
    });
  });

  function showResgatePopup(prizeName, pointsUsed) {
    const existingPopup = document.querySelector('.resgate-popup');
    if (existingPopup) existingPopup.remove();

    const popup = document.createElement('div');
    popup.className = 'resgate-popup';
    popup.innerHTML = `
      <div class="resgate-overlay">
        <div class="resgate-content">
          <button class="resgate-close">&times;</button>
          <div class="resgate-icon">🎁</div>
          <h3>Prêmio Resgatado!</h3>
          <p class="resgate-prize">${prizeName}</p>
          <p class="resgate-points">-${pointsUsed} pontos</p>
          <p class="resgate-message">Agora você pode usar seu cupom!</p>
          <button class="resgate-ok">OK</button>
        </div>
      </div>
    `;
    document.body.appendChild(popup);

    popup.querySelector('.resgate-close').addEventListener('click', () => popup.remove());
    popup.querySelector('.resgate-ok').addEventListener('click', () => popup.remove());
    popup.querySelector('.resgate-overlay').addEventListener('click', () => popup.remove());
  }

  const couponButton = document.querySelector('.coupon-button');
  const couponCode = document.querySelector('.coupon-code');

  if (couponButton && couponCode) {
    couponButton.addEventListener('click', function () {
      const code = couponCode.textContent.trim();

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(code).then(function () {
          showResgatadoPopup();

          couponButton.textContent = '✓ Resgatado';
          couponButton.style.background = '#e53935';
          couponButton.style.color = 'white';
          couponButton.style.cursor = 'default';

        }, function () {
          alert('Erro ao copiar o cupom');
        });
      }
    });
  }

  function showResgatadoPopup() {
    const existingPopup = document.querySelector('.resgatado-popup');
    if (existingPopup) existingPopup.remove();

    const popup = document.createElement('div');
    popup.className = 'resgatado-popup';
    popup.innerHTML = `
      <div class="resgatado-overlay">
        <div class="resgatado-content">
          <button class="resgatado-close">&times;</button>
          <div class="resgatado-icon">✓</div>
          <h3>Cupom Resgatado!</h3>
          <p>Seu cupom foi copiado com sucesso.</p>
          <p class="resgatado-codigo">Código: ${document.querySelector('.coupon-code').textContent.trim()}</p>
        </div>
      </div>
    `;
    document.body.appendChild(popup);

    popup.querySelector('.resgatado-close').addEventListener('click', () => popup.remove());
    popup.querySelector('.resgatado-overlay').addEventListener('click', () => popup.remove());

    setTimeout(() => popup.remove(), 4000);
  }
});